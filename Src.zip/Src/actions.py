from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_core_sdk import Action
from rasa_core_sdk.events import SlotSet

class ActionInformacionDia(Action):
	def name(self):
		return 'action_informacion_dia'
		
	def run(self, dispatcher, tracker, domain):
		import datetime
    	x = datetime.datetime.now()
     
    	dicdias = {'MONDAY':'Lunes','TUESDAY':'Martes','WEDNESDAY':'Miercoles','THURSDAY':'Jueves', \
    	'FRIDAY':'Viernes','SATURDAY':'Sabado','SUNDAY':'Domingo'}
    	anho = x.year
    	mes =  x.month
    	dia= x.day
     
    	fecha = datetime.date(anho, mes, dia)
    	dia = dicdias[fecha.strftime('%A').upper()])

		sub = ""
		if dia == "lunes":
			sub = "Pollo"
		elif dia == "Martes":
			sub = "italianisimo"
		elif dia == "Miercoles":
			sub = "Carne"
		elif dia == "Jueves":
			sub = "Atun"
		elif dia == "Viernes":
			sub = "Italiano BTM"
		elif dia == "Sabado":
			sub = "cerdo BBQ"
		elif dia == "Domingo":
			sub = "Pavo y jamon"
		
		response =  "el subway del dia es " +  sub 
		dispatcher.utter_message(response)
		return [SlotSet('Tipo',sub)]



