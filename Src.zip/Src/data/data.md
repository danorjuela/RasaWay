## intent:greet
- hola
- hola de nuevo
- hey
- buenas
- buen dia
- buenos dias
- buenas tardes
- buenas noches
- Hola
- Hola de nuevo
- Hey
- Buenas
- Huen dia
- Buenos dias
- Buenas tardes
- Buenas noches

## intent:goodbye
- adios
- chao
- suerte
- Que bien Gracias
- gracias
- nos vemos
- nos vemos luego
- Adios
- Chao
- Suerte
- que bien gracias
- Gracias
- Nos vemos
- Nos vemos luego
- listo 
- ok 

## intent:informacionDia
- Cual es el sub de hoy
- Que hay para hoy
- que sanduches hay 
- que sanduche tiene
- que me puede dar

## intent:pedido
- me das un subway
-cual es


## intent:pedidoTipo
- quiero un [baratisimo](Tipo)
- quiero uno de [jamon](Tipo)
- quiero uno de [Pavo y jamon](Tipo)
- quiero uno de [pechuga de pavo](Tipo)
- [pechuga de pavo](Tipo)
- [carne](Tipo)
- quiero un [italianisimo](Tipo)
- quiero uno de [cerdo desmechado](Tipo)
- quiero uno de [cerdo BBQ](Tipo)
- quiero uno de [pelluga de pollo](Tipo)
- quiero uno de [Italiano BTM](Tipo)
- quiero uno de [Costillas BBQ](Tipo)
- quiero uno de [Atun](Tipo)
- quiero uno de [Pollo Teriyaky](Tipo)
- quiero un [Melt](Tipo)
- quiero un [Club](Tipo)
- quiero un [Roasts Beef](Tipo)
- [baratisimo](Tipo)
- [jamon](Tipo)
- [Pavo y jamon](Tipo)
- [pechuga de pavo](Tipo)
- [italianisimo](Tipo)
- [cerdo desmechado](Tipo)
- [pelluga de pollo](Tipo)
- [Italiano BTM](Tipo)
- [Costillas BBQ](Tipo)
- [Atun](Tipo)
- [Pollo Teriyaky](Tipo)
- [Melt](Tipo)
- [Club](Tipo)
- [Roasts Beef](Tipo)

## intent:pedidoTamaño
- de [15](tamaño) cm
- de [30](tamaño) cm
- [15](tamaño)
- [30](tamaño)

## intent:pedidoPan
- [avena](pan)
- [blanco](pan)
- [oregano](pan)
- [integral](pan)
- con pan [avena](pan)
- con pan [blanco](pan)
- con pan [oregano](pan)
- con pan [integral](pan)

## intent:pedidoCoccion
- lo quiero [Caliete](coccion)
- lo quiero [frio](coccion)
- lo quiero [Tostado](coccion)
- [Caliete](coccion)
- [frio](coccion)
- [Tostado](coccion)

## intent:pedidoQueso
- con [Americano](queso) 
- con [Provolone](queso) 
- [Americano](queso) 
- [Provolone](queso) 

## intent:pedidoAdicionar
- agregale mas [Americano](adicion) 
- agregale mas [Provolone](adicion) 
- agregale mas [tocino](adicion) 
- agregale mas [pollo](adicion)
- agregale mas [peperoni](adicion) 
- agregale mas [carne](adicion) 
- adicional de [Americano](adicion) 
- adicional de [Provolone](adicion) 
- adicional de [tocino](adicion) 
- adicional de [pollo](adicion)
- adicional de [peperoni](adicion) 
- adicional de [carne](adicion) 

## intent:pedidoVegetales

- [Lechuga](vegetal)
- [Tomate](vegetal)
- [Pepino](vegetal)
- [Pepiillos](vegetal)
- [Pimenton](vegetal)
- [Cebolla](vegetal)
- [Aceitunas](vegetal)
- [Jalapechos](vegetal)


## intent:pedidoSalsas
- [Mayonesa](salsa) 
- [Cebolla Dulce](salsa) 
- [Mostaza Dulce](salsa) 
- [Moztaza](salsa) 
- [BBQ](salsa) 
- [Chipote](salsa) 
- [Rach](salsa) 
- [[Ajo](salsa) 


## intent:pedidoPapas

- Papitas [limon](papas) 
- Papitas [Pollo](papas) 
- Papitas [Naturales](papas) 
- Papitas [BBQ](papas) 
- papitas de [alitas](papas) 
- papitas de [sal](papas) 

## intent:pedidoGalletas

- Galleta de [choco Chips](galleta)
- Galleta de [doble Chocolate](galleta)
- Galleta [Macadamia](galleta)
- Galleta [Avenas pasas](galleta)


## intent:estado

- como va mi pedido 
- que llevo 


## intent:confirmacion

- me gusta
- asi es como lo quiero 

## intent:negacion

- esta horrible
- no lo quiero 
- no me gusta 
- esta asqueroso 
- Gas 
- cambiamelo 


## intent:greet+pedidoTipo
- hola quiero un [baratisimo](Tipo)
- hola de nuevo quiero uno de [jamon](Tipo)
- hey , quiero uno de [Pavo y jamon](Tipo)
- buenas, quiero uno de [pechuga de pavo](Tipo)
- buen dia,  dame uno [pechuga de pavo](Tipo)
- buenos dias, quiero un [italianisimo](Tipo)
- buenas tardes, quiero uno de [cerdo desmechado](Tipo)
- buenas noches, quiero uno de [pelluga de pollo](Tipo)
- Hola, quiero uno de [Italiano BTM](Tipo)
- Hola de nuevo, quiero uno de [Costillas BBQ](Tipo)
- Hey, quiero uno de [Atun](Tipo)
- Buenas, quiero uno de [Pollo Teriyaky](Tipo)
- Huen dia, quiero un [Melt](Tipo)
- Buenos diasquiero un [Club](Tipo)
- Buenas tardes, quiero un [Roasts Beef](Tipo)
- Buenas noches,  quiero un [baratisimo](Tipo)

## intent:greet+pedidoTipo+pedidoTamaño
- hola quiero un [baratisimo](Tipo) de [15](tamaño) cm
- hola de nuevo quiero uno de [jamon](Tipo) de [30](tamaño) cm
- hey , quiero uno de [Pavo y jamon](Tipo) de [15](tamaño)
- buenas, quiero uno de [pechuga de pavo](Tipo) de [30](tamaño)
- buen dia,  dame uno [pechuga de pavo](Tipo) de [15](tamaño) cm
- buenos dias, quiero un [italianisimo](Tipo) de [30](tamaño) cm
- buenas tardes, quiero uno de [cerdo desmechado](Tipo) de [30](tamaño) cm
- buenas noches, quiero uno de [pelluga de pollo](Tipo) de [15](tamaño)
- Hola, quiero uno de [Italiano BTM](Tipo) de [30](tamaño) cm
- Hola de nuevo, quiero uno de [Costillas BBQ](Tipo)de [15](tamaño)
- Hey, quiero uno de [Atun](Tipo) de [30](tamaño)
- Buenas, quiero uno de [Pollo Teriyaky](Tipo) de [30](tamaño) cm
- Huen dia, quiero un [Melt](Tipo) de [30](tamaño) cm
- Buenos diasquiero un [Club](Tipo) de [30](tamaño) cm
- Buenas tardes, quiero un [Roasts Beef](Tipo) de [30](tamaño)
- Buenas noches,  quiero un [baratisimo](Tipo) de [30](tamaño) cm

## intent:greet+pedidoTipo+pedidoTamaño+pedidoPan
- hola quiero un [baratisimo](Tipo) de [15](tamaño) cm, en pan [avena](pan)
- hola de nuevo quiero uno de [jamon](Tipo) de [30](tamaño) cm, con pan [blanco](pan)
- hey , quiero uno de [Pavo y jamon](Tipo) de [15](tamaño), con pan [oregano](pan)
- buenas, quiero uno de [pechuga de pavo](Tipo) de [30](tamaño), con pan [integral](pan)
- buen dia,  dame uno [pechuga de pavo](Tipo) de [15](tamaño) cm con pan [integral](pan)
- buenos dias, quiero un [italianisimo](Tipo) de [30](tamaño) cm con pan [blanco](pan)
- buenas tardes, quiero uno de [cerdo desmechado](Tipo) de [30](tamaño) cm con pan [oregano](pan)
- buenas noches, quiero uno de [pelluga de pollo](Tipo) de [15](tamaño) con pan [blanco](pan)
- Hola, quiero uno de [Italiano BTM](Tipo) de [30](tamaño) cm con pan [blanco](pan) con pan [integral](pan)
- Hola de nuevo, quiero uno de [Costillas BBQ](Tipo)de [15](tamaño) con pan [integral](pan)
- Hey, quiero uno de [Atun](Tipo) de [30](tamaño)  con pan [integral](pan)
- Buenas, quiero uno de [Pollo Teriyaky](Tipo) de [30](tamaño) cm  con pan [integral](pan)
- Huen dia, quiero un [Melt](Tipo) de [30](tamaño) cm en  con pan [integral](pan)
- Buenos diasquiero un [Club](Tipo) de [30](tamaño) cm en con pan [integral](pan)
- Buenas tardes, quiero un [Roasts Beef](Tipo) de [30](tamaño) con pan [integral](pan)
- Buenas noches,  quiero un [baratisimo](Tipo) de [30](tamaño) cm con pan [integral](pan)